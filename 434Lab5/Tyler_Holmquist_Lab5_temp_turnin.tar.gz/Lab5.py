#! /usr/bin/env python3
import sys
from scapy.all import *


def process_packet(packet):
    #packet.show()
    return packet[IP].id
        


def main():
    pingr = IP(dst="192.168.67.3",src="192.168.66.3")/ICMP()
    pingr2 = IP(dst='192.168.67.3',src="192.168.66.1")/ICMP()
    capt = sr1(pingr)
    capt2 = sr1(pingr2)
    print(capt.id)
    print(capt2.id)
    
    
    '''
    c = 5
    numList = [0] * c
    cap = sniff(filter="icmp and inbound",prn=process_packet, count=c)
    cap.show()
    for i in range(c):
        a = str(cap[i].id)
        numList[i] = a
    #for i in range(numList):
    '''
        


if __name__ == "__main__":
    main()
